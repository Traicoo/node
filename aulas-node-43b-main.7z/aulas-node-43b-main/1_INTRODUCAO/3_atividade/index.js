// Crie duas variáveis e mostre no console (terminal) a soma entre elas
const n1 = 23
const n2 = 46
console.log(n1 + n2)