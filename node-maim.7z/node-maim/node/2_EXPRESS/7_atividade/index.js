const express = require('express')
const app = express()

const path = require('path')
const caminho = path.join(__dirname, 'templates')

app.post('/users/salvar', (req, res) => {
    console.log(req.body.nome)
})

app.get('/users/cadastrar', (req, res) => {
    res.sendFile(`${caminho}/cadastro.html`)
})

app.get('/users/:id', (req, res) => {
    const id = req.params.id

    console.log(`Estamos buscando pelo usuario: ${id}`)
    res.sendFile(`${caminho}/usuarios.html`)
}) 

app.get ('/', (req, res) => {
    res.sendFile(`${caminho}/index.html`)
})

app.listen(5000)